---
widget: slider
headless: true
active: true
weight: 10
design:
  autoplay: true
  interval: 5000  # 5초
content:
  slides:
    - title: "포트폴리오에 오신 것을 환영합니다"
      image: "images/sans1.png"
    - title: "프로젝트를 둘러보세요"
      image: "images/sans2.png"
    - title: "연락은 아래에서"
      image: "images/sans3.png"
---