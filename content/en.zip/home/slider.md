---
widget: slider
headless: true
active: true
weight: 1
design:
  autoplay: true
  interval: 5000
content:
  slides:
    - title: "Welcome to my portfolio"
      image: "images/sans1.png"
    - title: "Explore my projects"
      image: "images/sans2.png"
    - title: "Get in touch below"
      image: "images/sans3.png"
---