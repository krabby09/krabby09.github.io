---
cms_exclude: true

# To publish author profile pages, remove all of the `build` and `cascade` settings below.
build:
  render: never
cascade:
  build:
    render: never
    list: always
---
